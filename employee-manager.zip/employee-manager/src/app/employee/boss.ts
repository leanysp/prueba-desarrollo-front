
export class Boss {
  id: number;
  fullname: string;
  identification: string;
  function: string;

  constructor() {
    this.id = 0;
    this.fullname = "";
    this.identification = "";
    this.function = "";
  }

}